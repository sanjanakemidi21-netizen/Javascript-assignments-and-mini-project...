# JavaScript Assignments & Mini Project

A beginner-friendly JavaScript portfolio containing six practical assignments and one capstone mini project, based on the supplied **JavaScript Curriculum: Student Assignments & Capstone Project** guide.

## Contents
- `assignments/01-variables-data-types.js` — variables, data types, and console operations
- `assignments/02-operators-input.js` — prompt input, type conversion, arithmetic
- `assignments/03-conditional-logic.js` — if/else, switch, ternary operator
- `assignments/04-loops.js` — for, while, break, do/while, continue
- `assignments/05-functions-scope.js` — functions, arrow functions, default parameters, scope
- `assignments/06-arrays-objects-methods.js` — objects, `forEach`, `filter`, and `map`
- `mini-project/index.html` — browser UI for the capstone
- `mini-project/style.css` — simple responsive styling
- `mini-project/app.js` — interactive Product Inventory & Analytics Dashboard

## Run the assignments
1. Install a modern browser such as Chrome or Edge.
2. Open a `.js` assignment in VS Code.
3. Run it in a browser console, or use Node.js for assignments that do not use `prompt()`.
4. Assignment 2 and the mini project use browser `prompt()`/DOM APIs, so open the mini-project HTML in a browser or run the assignment from an HTML page.

For Assignment 1, 3–6, you can also use Node.js:
```bash
node assignments/01-variables-data-types.js
```

## Run the mini project
Double-click `mini-project/index.html`, or use VS Code's Live Server extension. Add a product, review the inventory table, and use the dashboard statistics and filters.

## Expected output notes
The console output follows the supplied guide's examples. The guide's Assignment 4 expected output only shows the multiplication table and the first number greater than 10 divisible by 6; the `do...while` section is included in code too. The capstone is implemented as a working browser dashboard while retaining the guide's core requirements.

## Repository structure
```text
javascript-assignments-and-mini-project/
├── README.md
├── .gitignore
├── LICENSE
├── assignments/
│   ├── 01-variables-data-types.js
│   ├── 02-operators-input.js
│   ├── 03-conditional-logic.js
│   ├── 04-loops.js
│   ├── 05-functions-scope.js
│   └── 06-arrays-objects-methods.js
└── mini-project/
    ├── index.html
    ├── style.css
    └── app.js
```

## Skills demonstrated
Variables and types, operators, user input, conditional statements, loops, functions, scope, arrays, objects, and array methods.

## License
MIT — see `LICENSE`.
