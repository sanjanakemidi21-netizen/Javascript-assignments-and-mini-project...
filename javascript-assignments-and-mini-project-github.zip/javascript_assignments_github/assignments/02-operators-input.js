// Assignment 2: Operators, Expressions, and Input Handling
// Run this file in a browser because it uses prompt().

const billAmount = Number(prompt("Enter bill amount:", "100"));
const tipPercentage = Number(prompt("Enter tip percentage:", "15"));

if (!Number.isFinite(billAmount) || billAmount < 0 ||
    !Number.isFinite(tipPercentage) || tipPercentage < 0) {
  console.log("Please enter valid non-negative numbers.");
} else {
  const tip = billAmount * tipPercentage / 100;
  let total = billAmount;
  total += tip;

  console.log(`Subtotal: $${billAmount}`);
  console.log(`Tip Percentage: ${tipPercentage}%`);
  console.log(`Calculated Tip: $${tip}`);
  console.log(`Total Amount to Pay: $${total}`);
}
