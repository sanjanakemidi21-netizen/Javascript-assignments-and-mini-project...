// Capstone: Interactive Product Inventory & Analytics Dashboard

"use strict";

const inventory = [
  { name: "Laptop", price: 800 },
  { name: "Mouse", price: 25 }
];

const form = document.querySelector("#product-form");
const nameInput = document.querySelector("#product-name");
const priceInput = document.querySelector("#product-price");
const message = document.querySelector("#message");
const inventoryBody = document.querySelector("#inventory-body");
const filterSelect = document.querySelector("#filter");

const formatMoney = amount => `$${amount.toFixed(2)}`;

function getCategory(price) {
  if (price < 50) return "Budget";
  if (price < 200) return "Standard";
  return "Premium";
}

function calculateTotal(items = inventory) {
  return items.reduce((sum, item) => sum + item.price, 0);
}

const calculateAfterTax = (amount, taxRate = 0) => amount * (1 + taxRate / 100);

function renderInventory() {
  const filter = filterSelect.value;
  let visibleItems = inventory.map((item, index) => ({ ...item, index }));

  if (filter === "affordable") {
    visibleItems = visibleItems.filter(item => item.price < 200);
  } else if (filter === "premium") {
    visibleItems = visibleItems.filter(item => item.price >= 500);
  }

  inventoryBody.replaceChildren();
  visibleItems.forEach(item => {
    const row = document.createElement("tr");
    const nameCell = document.createElement("td");
    const priceCell = document.createElement("td");
    const categoryCell = document.createElement("td");
    const actionCell = document.createElement("td");
    const category = document.createElement("span");
    const removeButton = document.createElement("button");

    nameCell.textContent = item.name;
    priceCell.textContent = formatMoney(item.price);
    category.className = "pill";
    category.textContent = getCategory(item.price);
    categoryCell.append(category);
    removeButton.type = "button";
    removeButton.className = "delete-button";
    removeButton.textContent = "Remove";
    removeButton.setAttribute("aria-label", `Remove ${item.name}`);
    removeButton.addEventListener("click", () => {
      inventory.splice(item.index, 1);
      renderInventory();
    });
    actionCell.append(removeButton);
    row.append(nameCell, priceCell, categoryCell, actionCell);
    inventoryBody.append(row);
  });

  document.querySelector("#product-count").textContent = inventory.length;
  document.querySelector("#inventory-total").textContent = formatMoney(calculateTotal());
  document.querySelector("#affordable-count").textContent =
    inventory.filter(item => item.price < 200).length;

  const report = document.querySelector("#report-list");
  report.replaceChildren();
  inventory.map(item => `${item.name.toUpperCase()}: ${formatMoney(item.price)}`)
    .forEach(line => {
      const li = document.createElement("li");
      li.textContent = line;
      report.append(li);
    });
}

form.addEventListener("submit", event => {
  event.preventDefault();
  const name = nameInput.value.trim();
  const price = Number(priceInput.value);

  if (!name) {
    message.textContent = "Please enter a product name.";
    return;
  }
  if (!Number.isFinite(price) || price <= 0) {
    message.textContent = "Please enter a price greater than zero.";
    return;
  }

  // switch demonstrates category evaluation from the price-based category.
  const category = getCategory(price);
  switch (category) {
    case "Budget":
    case "Standard":
    case "Premium":
      inventory.push({ name, price });
      break;
    default:
      message.textContent = "Could not classify this product.";
      return;
  }

  const afterTax = calculateAfterTax(price, 0);
  message.textContent = `${name} added as ${category}. Price with 0% tax: ${formatMoney(afterTax)}.`;
  form.reset();
  renderInventory();
});

filterSelect.addEventListener("change", renderInventory);
renderInventory();
